package com.example.demo.Model;

import java.util.List;

public class OrderMainn {
    public String orderDate;
    public List<items> items;
}
