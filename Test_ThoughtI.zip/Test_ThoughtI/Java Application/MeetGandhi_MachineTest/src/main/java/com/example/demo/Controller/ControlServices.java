package com.example.demo.Controller;

import com.example.demo.Model.OrderMainn;
import org.springframework.web.bind.annotation.*;
import com.example.demo.repositories.OrdersDB;
import java.util.List;


@RestController
public class ControlServices {


    @RequestMapping(path="/order/{order_id}")
    public String getOrders( @PathVariable("order_id") String order_id) throws  Exception{

       return OrdersDB.getOrders(order_id);
    }

    @PostMapping("/order/create")
    public String addOrder(@RequestBody List<OrderMainn> json) throws Exception {
        return OrdersDB.postOrders(json);
    }
    @GetMapping("/orders")
    public String getallOrders() throws  Exception{
        return OrdersDB.getAllOrders();
    }

}
