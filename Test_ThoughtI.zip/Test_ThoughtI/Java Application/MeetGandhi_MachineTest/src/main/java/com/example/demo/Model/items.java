package com.example.demo.Model;

import java.io.Serializable;

public class items implements Serializable {
   public String itemName;
   public String itemUnitPrice;
   public int  itemQuantity;
}
