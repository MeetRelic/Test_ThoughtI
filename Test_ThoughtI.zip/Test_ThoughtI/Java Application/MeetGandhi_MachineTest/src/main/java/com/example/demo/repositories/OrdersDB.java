package com.example.demo.repositories;

import com.example.demo.Model.OrderMainn;
import com.example.demo.Model.items;
import com.mysql.cj.jdbc.Driver;
import org.json.JSONObject;
import org.json.JSONArray;
import java.sql.*;
import java.time.LocalDate;
import java.util.List;

public class OrdersDB {
    private static ResultSet rs;
    private static Connection conn;
    private static Statement st;
    private static final String URL = "jdbc:mysql://localhost:3306/test_thoughti_db?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";

    private static final String user = "root";
    private static final String pass = ""; //u can change ur pass or roots


//GetOrder with id from pathvariable
    public static String getOrders(String id) throws Exception {

        DriverManager.registerDriver(new Driver());
        conn = DriverManager.getConnection(URL,user,pass);
        st=conn.createStatement();
        String query = "select * from  `order` WHERE `order`.`orderId` = "+Integer.parseInt(id);
        rs = st.executeQuery(query);
        JSONArray array = new JSONArray();

        while(rs.next()){
            JSONObject obj = new JSONObject();
            obj.put("orderId " , "id");
            obj.put("orderDate " , rs.getString("orderDate"));
            obj.put("status","New");
            array.put(obj);

            String collect[] = rs.getString("collection of Items").split("to");
            int start = Integer.parseInt(collect[0]);
            int end = Integer.parseInt(collect[1]);
            while(start <= end){

                JSONObject record = new JSONObject();
                String queryitem = "select * from item where itemId = "+start;
                start++;
                ResultSet rs1;
                Statement s1=conn.createStatement();
                rs1 = s1.executeQuery(queryitem);
                while(rs1.next()){
                    record.put("itemId" , start);
                    record.put("itemName" ,rs1.getString("itemName"));
                    record.put("itemUnitPrice",rs1.getString("itemUnitPrice") );
                    record.put("itemQuantity" ,rs1.getString("itemQuantity"));
                    array.put(record);

                }

            }

        }

        return array.toString();

    }

//get All Orders
    public static String getAllOrders() throws  Exception{
        DriverManager.registerDriver(new Driver());
        conn = DriverManager.getConnection(URL,user,pass);
        st=conn.createStatement();
        String query = "select * from  `order`";
        rs = st.executeQuery(query);
        JSONArray array = new JSONArray();
        while(rs.next()){
            JSONObject obj = new JSONObject();
            obj.put("orderId " , "id");
            obj.put("orderDate " , rs.getString("orderDate"));
            obj.put("status","New");
            array.put(obj);

            String collect[] = rs.getString("collection of Items").split("to");
            int start = Integer.parseInt(collect[0]);
            int end = Integer.parseInt(collect[1]);
            while(start <= end){

                JSONObject record = new JSONObject();
                String queryitem = "select * from item where itemId = "+start;
                start++;
                ResultSet rs1;
                Statement s1=conn.createStatement();
                rs1 = s1.executeQuery(queryitem);
                while(rs1.next()){
                    record.put("itemId" , start);
                    record.put("itemName" ,rs1.getString("itemName"));
                    record.put("itemUnitPrice",rs1.getString("itemUnitPrice") );
                    record.put("itemQuantity" ,rs1.getString("itemQuantity"));
                    array.put(record);

                }

            }

        }

        return array.toString();
    }

    //Post/create Orders
    public static String postOrders(List<OrderMainn> jsonData) throws Exception {

        DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
        conn = DriverManager.getConnection(URL,user,pass);
        st=conn.createStatement();
 //first we get Id of Max Orders and ALso items as we meed to store the the id in foreign key for items and we need to track collection of items also
        int itemid = 0;
        rs = st.executeQuery("SELECT MAX(itemId) FROM  `item` ");

        if(rs.next()){
            itemid = rs.getInt(1)+1;
        }
        String orderDate= LocalDate.now().toString();
        //Now we work on our Data to insert
        for(OrderMainn OrderedData : jsonData){


            String itemName;
            String itemUnitPrice;
            int itemQuantity;
             for(items itemdata : OrderedData.items){
                itemName = itemdata.itemName;
                itemUnitPrice = itemdata.itemUnitPrice;
                itemQuantity = itemdata.itemQuantity;
                //insert query
                    st.execute("INSERT INTO `item` ( `itemName`, `itemUnitPrice`, `itemQuantity`) VALUES ( '"+itemName+"', '"+itemUnitPrice+"', '"+itemQuantity+"')");
             }
            }
        int itemidend = 0;
        rs = st.executeQuery("SELECT MAX(itemId) FROM  `item` ");
        if(rs.next()){
            itemidend = rs.getInt(1);
        }
         //add collections of id from start id to end in order id
        String starttoend = String.valueOf(itemid) + "to"+String.valueOf(itemidend);
        st.execute("INSERT INTO `order` ( `orderDate`, `orderStatus`, `collection of Items`) VALUES ( '"+orderDate+"', 'New', '"+starttoend+"');");

        return "Inserted Successfully";
    }



}
